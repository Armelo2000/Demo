/* Filename: cancomm.c */

#include <LMV1_app_definitions.h>

#pragma CODE_SECTION(Process_can_data, ".TI.ramfunc");


void Process_can_data(mboxdata *DATA)  //
{

  // Nachricht u.a. zum Wechseln in Bootloader (DLC = 4)
  if (DATA->ident == 0x1FFFFFFF)  Bl_message(DATA);

}




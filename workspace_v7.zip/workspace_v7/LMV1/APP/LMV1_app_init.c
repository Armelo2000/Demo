#include <LMV1_app_definitions.h>

void Init_gpios(void)
{
  EALLOW;

  GpioDataRegs.GPADAT.all=0x00000000;   // alle GPIOS auf null setzen
  GpioDataRegs.GPBDAT.all=0x00000000;   // alle GPIOS auf null setzen
  GpioDataRegs.GPHDAT.all=0x00000000;   // alle GPIOS auf null setzen

  // GPIO 0,  Pin 52, LCD_D0
  GpioCtrlRegs.GPAGMUX1.bit.GPIO0 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO0  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO0   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO0   = 1;    // Output

  // GPIO 1, Pin 51, LCD_D1
  GpioCtrlRegs.GPAGMUX1.bit.GPIO1 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO1  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO1   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO1   = 1;    // Output

  // GPIO 2, Pin 50, LCD_D2
  GpioCtrlRegs.GPAGMUX1.bit.GPIO2 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO2  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO2   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO2   = 1;    // Output

  // GPIO 3, Pin 49, LCD_D3
  GpioCtrlRegs.GPAGMUX1.bit.GPIO3 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO3  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO3   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO3   = 1;    // Output

  // GPIO 4, Pin 48, LCD_RS
  GpioCtrlRegs.GPAGMUX1.bit.GPIO4 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO4  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO4   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO4   = 1;    // Output

  // GPIO 5, Pin 61, LCD_E
  GpioCtrlRegs.GPAGMUX1.bit.GPIO5 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO5  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO5   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO5   = 1;    // Output

  // GPIO 6, Pin 64
  GpioCtrlRegs.GPAPUD.bit.GPIO6   = 0;    // Pullup enabled
  GpioCtrlRegs.GPADIR.bit.GPIO6   = 0;    // Input

  // GPIO 7, Pin 57
  GpioCtrlRegs.GPAPUD.bit.GPIO7   = 0;    // Pullup enabled
  GpioCtrlRegs.GPADIR.bit.GPIO7   = 0;    // Input

  // GPIO 8, Pin 47, CAN B TX
  GpioCtrlRegs.GPAGMUX1.bit.GPIO8 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO8  = 0b10;
  GpioCtrlRegs.GPAPUD.bit.GPIO8   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO8   = 1;    // Output

  // GPIO 9, Pin 62
  GpioCtrlRegs.GPAPUD.bit.GPIO9   = 0;    // Pullup enabled
  GpioCtrlRegs.GPADIR.bit.GPIO9   = 0;    // Input

  // GPIO 10, Pin 63, CAN B RX
  GpioCtrlRegs.GPAGMUX1.bit.GPIO10 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO10  = 0b10;
  GpioCtrlRegs.GPAPUD.bit.GPIO10   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO10   = 0;    // Input
  GpioCtrlRegs.GPAQSEL1.bit.GPIO10 = 3;    // asynchron

  // GPIO 11, Pin 31, SCIA_EN
  GpioCtrlRegs.GPAGMUX1.bit.GPIO11 = 0b00;
  GpioCtrlRegs.GPAMUX1.bit.GPIO11  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO11   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO11   = 1;    // Output

  // GPIO 12, Pin 30, LED Gr�n
  GpioCtrlRegs.GPAPUD.bit.GPIO12   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO12   = 1;    // Output

  // GPIO 13, GPIO 13, Pin 29, LED Rot
  GpioCtrlRegs.GPAPUD.bit.GPIO13   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO13   = 1;    // Output

  // GPIO 14, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO14   = 0;    // Pullup enabled
  GpioCtrlRegs.GPADIR.bit.GPIO14   = 0;    // Input

  // GPIO 15, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO15   = 0;    // Pullup enabled

  // GPIO 16, Pin 33
  GpioCtrlRegs.GPAPUD.bit.GPIO16   = 0;    // Pullup enabled
  GpioCtrlRegs.GPADIR.bit.GPIO16   = 0;    // Input

  // GPIO 17, Pin 34
  GpioCtrlRegs.GPAPUD.bit.GPIO17   = 0;    // Pullup enabled
  GpioCtrlRegs.GPADIR.bit.GPIO17   = 0;    // Input

  // GPIO 18, Pin 41, X2, Wird durch die Oszillatoreinstellung eingestellt
  // GPIO 19, kein Pin
  // GPIO 20, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO20   = 0;    // Pullup enabled

  // GPIO 21, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO21   = 0;    // Pullup enabled

  // GPIO 22, Pin 56
  GpioCtrlRegs.GPAAMSEL.bit.GPIO22 = 0;    // Switch to GPIO-Mode
  GpioCtrlRegs.GPAPUD.bit.GPIO22   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO22   = 1;    // Output

  // GPIO 23, GPIO 23, Pin 54
  GpioCtrlRegs.GPAAMSEL.bit.GPIO23 = 0;    // Switch to GPIO-Mode
  GpioCtrlRegs.GPAPUD.bit.GPIO23   = 0;    // Pullup enabled
  GpioCtrlRegs.GPADIR.bit.GPIO23   = 0;    // Input

  // GPIO 24, Pin 35, BM1
  GpioCtrlRegs.GPAPUD.bit.GPIO24   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO24   = 0;    // Input

  // GPIO 25, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO25   = 0;    // Pullup enabled

  // GPIO 26, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO26   = 0;    // Pullup enabled

  // GPIO 27, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO27   = 0;    // Pullup enabled

  // GPIO 28, Pin 2, SCIA_TX
  GpioCtrlRegs.GPAGMUX2.bit.GPIO28 = 0b00;
  GpioCtrlRegs.GPAMUX2.bit.GPIO28  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO28   = 1;    // Pullup disabled
  GpioCtrlRegs.GPADIR.bit.GPIO28   = 1;    // Output

  // GPIO 29, Pin 1, SCIA_RX
  GpioCtrlRegs.GPAGMUX2.bit.GPIO29 = 0b00;
  GpioCtrlRegs.GPAMUX2.bit.GPIO29  = 0b00;
  GpioCtrlRegs.GPAPUD.bit.GPIO29   = 0;    // Pullup enabled
  GpioCtrlRegs.GPADIR.bit.GPIO29   = 0;    // Input

  // GPIO 30, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO30   = 0;    // Pullup enabled

  // GPIO 31, kein Pin
  GpioCtrlRegs.GPAPUD.bit.GPIO31   = 0;    // Pullup enabled

  // GPIO 32, Pin 40, SDA+BM0
  GpioCtrlRegs.GPBGMUX1.bit.GPIO32 = 0b00;
  GpioCtrlRegs.GPBMUX1.bit.GPIO32  = 0b01;
  GpioCtrlRegs.GPBPUD.bit.GPIO32   = 1;    // Pullup disabled
  GpioCtrlRegs.GPBDIR.bit.GPIO32   = 1;    // Output
  GpioCtrlRegs.GPBODR.bit.GPIO32   = 1;    // Open drain

  // GPIO 33, Pin 32, SCL
  GpioCtrlRegs.GPBGMUX1.bit.GPIO33 = 0b00;
  GpioCtrlRegs.GPBMUX1.bit.GPIO33  = 0b01;
  GpioCtrlRegs.GPBPUD.bit.GPIO33   = 1;    // Pullup disabled
  GpioCtrlRegs.GPBDIR.bit.GPIO33   = 1;    // Output
  GpioCtrlRegs.GPBODR.bit.GPIO33   = 1;    // Open drain

  // GPIO 34, kein Pin
  GpioCtrlRegs.GPBPUD.bit.GPIO34   = 0;    // Pullup enabled

  // GPIO 35, Pin 63, TDI, ab Reset bereits korrekt eingestellt

  // GPIO 36 existiert nicht

  // GPIO 37, Pin 61, TDO, ab Reset bereits korrekt eingestellt

  // GPIO 38 existiert nicht

  // GPIO39-59 keine Pins
  GpioCtrlRegs.GPBPUD.bit.GPIO39   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO40   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO41   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO42   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO43   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO44   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO45   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO46   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO47   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO48   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO49   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO50   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO51   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO52   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO53   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO54   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO55   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO56   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO57   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO58   = 0;    // Pullup enabled
  GpioCtrlRegs.GPBPUD.bit.GPIO59   = 0;    // Pullup enabled

  // GPIO60-63 existieren nicht
  EDIS;
}

void Init_system(void)
{
  InitSysCtrl();  // Initialize device clock and peripherals

  DINT; // Disable CPU interrupts

  Init_piectrl();// Initialize the PIE control registers to their default state.

  IER = 0x0000;    // Disable CPU interrupts and clear all CPU interrupt flags
  IFR = 0x0000;

  InitPieVectTable(); // Initialize the PIE vector table with pointers to the shell Interrupt Service Routines (ISR)

//Timer Interrupt mit Timer1 alle 10ms
  EALLOW;
  PieVectTable.TIMER1_INT =  &cpuTimer1ISR;
  PieVectTable.CANB0_INT = &Read_can_b_ISR;
  EDIS;

  CpuTimer1Regs.TCR.bit.TSS = 1;    // Stop timer 1
  CpuTimer1Regs.TPR.all  = 0;       // Sysclock-Divider = 1
  CpuTimer1Regs.TPRH.all = 0;
  CpuTimer1Regs.PRD.all = 1000000;  // alle 10ms
  CpuTimer1Regs.TCR.bit.TRB = 1;    // Reset to PRD
  CpuTimer1Regs.TCR.bit.FREE = 0;   //
  CpuTimer1Regs.TCR.bit.TIE = 1;    // Interrupt an
  //IER |= M_INT13;                   // Interrupt zulassen


  IER |= M_INT1;                      // Watchdog und externes Interrupt zulassen
  PieCtrlRegs.PIEIER1.bit.INTx10 = 1;  // Watchdog
  ERTM;


}

void Init_can(void)
{
  Init_can_module(); // Konfiguriere CAN B

  // Um die CAN-Weiterleitung abzuwickeln: F�r jeden CAN jeweils zwei Mailboxen f�r RX mit 2er-FIFO und 2x vier Mailboxen f�r TX

  // TX-Boxen f�r alle Sondernachrichten, werden dynamisch verwaltet mit Sowohl ID, L�nge und bis zu 8 Byte Daten
  Setup_can_obj(1, 1, 0x00000000, 1, 2, 0x00000000, 0x01); // Flags: 0b00000001 (0,0,0,0,0,0,0,single message)
  Setup_can_obj(1, 2, 0x00000000, 1, 2, 0x00000000, 0x01); // Flags: 0b00000001 (0,0,0,0,0,0,0,single message)
  Setup_can_obj(1, 3, 0x00000000, 1, 2, 0x00000000, 0x01); // Flags: 0b00000001 (0,0,0,0,0,0,0,single message)
  Setup_can_obj(1, 4, 0x00000000, 1, 2, 0x00000000, 0x01); // Flags: 0b00000001 (0,0,0,0,0,0,0,single message)

  // TX-Box f�r Standardnachrichten (16|16), ID wird dynamisch verwaltet, L�nge ist immer 2 Byte und 16bit-ID
  Setup_can_obj(1, 5, 0x00000000, 1, 2, 0x00000000, 0x01); // Flags: 0b00000001 (0,0,0,0,0,0,0,single message)
  Setup_can_obj(1, 6, 0x00000000, 1, 2, 0x00000000, 0x01); // Flags: 0b00000001 (0,0,0,0,0,0,0,single message)
  Setup_can_obj(1, 7, 0x00000000, 1, 2, 0x00000000, 0x01); // Flags: 0b00000001 (0,0,0,0,0,0,0,single message)
  Setup_can_obj(1, 8, 0x00000000, 1, 2, 0x00000000, 0x01); // Flags: 0b00000001 (0,0,0,0,0,0,0,single message)

  // RX-Box CAN-B, FiFo-Tiefe 2, Akzeptiert alle Nachrichten mit Extended-ID, MEssage-Objects 9 + 10
  Setup_can_obj(1, 9, 0x00009FFF, 0, 2, 0x80000000, 0x28); // Flags: 0b00001000 (0,0,keine Maske,0,Rx Int,0,0,not last of FIFO)
  Setup_can_obj(1, 10, 0x00009FFF, 0, 2, 0x80000000, 0x29); // Flags: 0b00001001 (0,0, keine Maske,0,Rx Int,0,0, last of FIFO)

  EALLOW;
  CanbRegs.CAN_GLB_INT_CLR.bit.INT0_FLG_CLR = 1;

  CanbRegs.CAN_GLB_INT_EN.bit.GLBINT0_EN = 1; // Enable INT0 auf Can B

  PieCtrlRegs.PIEIER9.all |= 0x40; // Enable Int7 in PIEIER Gruppe 9 -> CAN B 0

  //IER |= M_INT9;  // Interrupts Gruppe 9 zur CPU zulassen
}

void Init_variables(void)
{
  GLOBALS.hwid = 0xFFFF;

  CANCOMM.activity = 0;           // Abschalten des automatischen Nachrichtenwiederholens
  CANCOMM.send_delay = 0xFFFF;    // Keine Identifikation zeitgestuert senden, nur auf Anfrage
  CANCOMM.can_rr = 100;
  CANCOMM.uid_requested = 0;
  CANCOMM.delay1000 = 0;
  CANCOMM.can_silence = 0;
}

void Init_piectrl(void)
{
  DINT;     // Disable Interrupts at the CPU level:
  PieCtrlRegs.PIECTRL.bit.ENPIE = 0;     // Disable the PIE
  // Clear all PIEIER registers:
  PieCtrlRegs.PIEIER1.all = 0;
  PieCtrlRegs.PIEIER2.all = 0;
  PieCtrlRegs.PIEIER3.all = 0;
  PieCtrlRegs.PIEIER4.all = 0;
  PieCtrlRegs.PIEIER5.all = 0;
  PieCtrlRegs.PIEIER6.all = 0;
  PieCtrlRegs.PIEIER7.all = 0;
  PieCtrlRegs.PIEIER8.all = 0;
  PieCtrlRegs.PIEIER9.all = 0;
  PieCtrlRegs.PIEIER10.all = 0;
  PieCtrlRegs.PIEIER11.all = 0;
  PieCtrlRegs.PIEIER12.all = 0;
  // Clear all PIEIFR registers:
  PieCtrlRegs.PIEIFR1.all = 0;
  PieCtrlRegs.PIEIFR2.all = 0;
  PieCtrlRegs.PIEIFR3.all = 0;
  PieCtrlRegs.PIEIFR4.all = 0;
  PieCtrlRegs.PIEIFR5.all = 0;
  PieCtrlRegs.PIEIFR6.all = 0;
  PieCtrlRegs.PIEIFR7.all = 0;
  PieCtrlRegs.PIEIFR8.all = 0;
  PieCtrlRegs.PIEIFR9.all = 0;
  PieCtrlRegs.PIEIFR10.all = 0;
  PieCtrlRegs.PIEIFR11.all = 0;
  PieCtrlRegs.PIEIFR12.all = 0;
}

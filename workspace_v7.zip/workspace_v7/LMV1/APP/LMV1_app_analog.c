
#include <LMV1_app_definitions.h>


void Setup_adc(void)
{
  EALLOW;

  // Analog Subsystem
  AnalogSubsysRegs.ANAREFPP.bit.ANAREFCDIS = 1;   // Analoge Referenz C disabled (an B)
  AnalogSubsysRegs.TSNSCTL.bit.ENABLE = 1;  // Temperature Sensor eingeschaltet

  AnalogSubsysRegs.ANAREFCTL.all = 0;       // Interne 3.3V (1.65V) Referenz f�r alle ADC-Module

  AnalogSubsysRegs.DCDCCTL.bit.DCDCEN = 0;  // Internen DCDC-Schaltregler abschalten


  // AD-Wandlermodul A
  AdcaRegs.ADCCTL2.bit.PRESCALE = 8;    // SYSCLK / 5 = 20MHz
  AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;    // Power Up A

  // AD-Wandlermodul B
  AdcbRegs.ADCCTL2.bit.PRESCALE = 8;    // SYSCLK / 5 = 20MHz
  AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 1;    // Power Up B

  // AD-Wandlermodul C
  AdccRegs.ADCCTL2.bit.PRESCALE = 8;    // SYSCLK / 5 = 20MHz
  AdccRegs.ADCCTL1.bit.ADCPWDNZ = 1;    // Power Up C

}



// CAN-Datenregister mit Einzelzugriffen

struct  CANMDL_WORDS {      // bits  description
   unsigned short int      LOW_WORD:16; // 0:15
   unsigned short int      HI_WORD:16;  // 31:16
};

/* eCAN Message Data Register low (MDR_L) byte definitions */
struct  CANMDL_BYTES {      // bits   description
  unsigned short int      BYTE0:8;     // 31:24
  unsigned short int      BYTE1:8;     // 23:16
  unsigned short int      BYTE2:8;     // 15:8
  unsigned short int      BYTE3:8;     // 7:0
};


/* Allow access to the bit fields or entire register */

union CANMDL_REG {
   unsigned long int                all;
   struct CANMDL_WORDS   word;
   struct CANMDL_BYTES   byte;
};

/* eCAN Message Data Register high  (MDR_H) word definitions */
struct  CANMDH_WORDS {         // bits  description
  unsigned short int      LOW_WORD:16;    // 0:15
  unsigned short int      HI_WORD:16;     // 31:16
};

/* eCAN Message Data Register low (MDR_H) byte definitions */
struct  CANMDH_BYTES {      // bits   description
  unsigned short int      BYTE4:8;     // 63:56
  unsigned short int      BYTE5:8;     // 55:48
  unsigned short int      BYTE6:8;     // 47:40
  unsigned short int      BYTE7:8;     // 39:32
};

/* Allow access to the bit fields or entire register */
union CANMDH_REG {
   unsigned long int       all;
   struct CANMDH_WORDS     word;
   struct CANMDH_BYTES     byte;
};


struct MBOX {
   union CANMDL_REG       DATA_A;
   union CANMDH_REG       DATA_B;
};


struct Globals
{
  unsigned short int flashmode;
  unsigned short int flashsector;
  unsigned short int flashbuffer[16];
  unsigned short int flashbuffercnt;
  unsigned short int *flashadress;
  unsigned short int swinfowords[4];
  unsigned short int antibrick;
  unsigned char can_counter;
  unsigned char can_counter_flash;
  unsigned short int fehler;
  unsigned short int just_verify;
  unsigned short int hw_id;
  unsigned short int timer_250;

  unsigned short int ready;
  short int msec500_counter;
  unsigned short int send_delay;
  long int* appdate;
  long int test_data;

};

extern struct Globals GLOBALS;

/* Filename: flash.c */
#include <LMV1_boot_definitions.h>


#pragma CODE_SECTION(erase, ".TI.ramfunc");
#pragma CODE_SECTION(program, ".TI.ramfunc");
#pragma CODE_SECTION(verify, ".TI.ramfunc");
#pragma CODE_SECTION(flash_confirm, ".TI.ramfunc");

void erase(void)
{
  unsigned short int fehler = 0, i;
  unsigned long int nopcount;

  Fapi_FlashStatusWordType oFlashStatusWord;

  GLOBALS.flashmode = 1;

  DINT;                                                                                                   // Interrupts unterbinden

  for (i = 0; i < 14; i++) // Beginnend mit dem zweiten Sektor
  {
    fehler = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector, (uint32 *) (0x00080000 + (0x1000 * (i + 2))) );   // Erase Sektor 2-15
    GLOBALS.flashsector = i;                                                                              // Mitteilung �ber CAN f�r Fortschrittsbalken als 0-13
    Send_can(0,0);
    while(Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}                                              // Warten auf Abschluss des L�schvorgangs
    WdRegs.WDKEY.all = 0x55;
    WdRegs.WDKEY.all = 0xAA;                                                                              // reset watchdog

    for (nopcount = 0; nopcount < 150000; nopcount++);  // Kurz warten


    WdRegs.WDKEY.all = 0x55;
    WdRegs.WDKEY.all = 0xAA;                                                                              // reset watchdog
    fehler += Fapi_getFsmStatus();                                                                        // Pr�fe auf fehler beim L�schvorgang

    if (fehler) i = 16; // quasi break
    else fehler = Fapi_doBlankCheck((uint32 *) (0x00080000 + (0x1000 * (i + 2))), 0x0800, &oFlashStatusWord);    // Pr�fen ob Flashsektor erfolgreich geleert, Sektorl�nge in 32bit-Worten 0x0800 = 2048 x 32 = 4096 x 16
    if (fehler) i = 16; // quasi break
  }
  if (fehler) Send_can(1, fehler);                                                                        // ggf. Fehlermeldung

  EINT;                                                                                                   // Interrupts wieder zulassen
  GLOBALS.flashsector = 0;
  GLOBALS.flashmode = 0;
  for (nopcount = 0; nopcount < 200000; nopcount++);                                                      // Kurz warten
  Send_can(0, 0);
  Send_can(2, 0);
}

void program(void)
{
  unsigned long int *flashbegin;
  unsigned short int fehler;

	DINT;

	flashbegin = (void*) (0x00082000 + GLOBALS.flashadress);      // neuen Flashbeginn berechen

	fehler = Fapi_issueProgrammingCommand((void*)flashbegin, (void*)GLOBALS.flashbuffer, 4, 0, 0, Fapi_AutoEccGeneration);  // Programmieren

	while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}     // Warten bis Programmiervorgang abgeschlossen

	fehler += Fapi_getFsmStatus();                                // Pr�fe auf Fehler beim Programmiervorgang

	if (fehler)                                                   // Fehlermeldung versenden
	{
	  Send_can(1, fehler);
	  GLOBALS.flashmode = 0;
	}
	EINT;
}

void verify(void)
{
  Fapi_FlashStatusWordType oFlashStatusWord;
  unsigned long int *flashbegin;
  unsigned short int fehler=0;

  flashbegin = (void*) (0x00082000);
  if ((*flashbegin != 0xFFFFFFFF) && (!GLOBALS.flashadress)) // wenn Firmware schon best�tigt wurde, wird mit den wirklichen Hexdaten verglichen
  {
    GLOBALS.flashbuffer[0] = GLOBALS.swinfowords[0];
    GLOBALS.flashbuffer[1] = GLOBALS.swinfowords[1];
    GLOBALS.flashbuffer[2] = GLOBALS.swinfowords[2];
    GLOBALS.flashbuffer[3] = GLOBALS.swinfowords[3];

    GLOBALS.just_verify=1;
  }
  else GLOBALS.just_verify = 0;

  DINT;
  // Immer 32 bytes auf einmal pr�fen -> 2 32-bit-words
  flashbegin = (void*) (0x00082000 + GLOBALS.flashadress);		// neuen Flashbeginn berechen

  fehler =  Fapi_doVerify((void*)flashbegin, 2, (void*)GLOBALS.flashbuffer, &oFlashStatusWord);

  EINT;

	if (fehler)	// Fehlermeldung
	{
	  Send_can(1, fehler);	// Fehlermeldung
	  GLOBALS.flashmode = 0;
	}
}


void flash_confirm(void)
{
  unsigned short int fehler=0;

  GLOBALS.flashbuffer[0] = GLOBALS.swinfowords[0];
  GLOBALS.flashbuffer[1] = GLOBALS.swinfowords[1];
  GLOBALS.flashbuffer[2] = GLOBALS.swinfowords[2];
  GLOBALS.flashbuffer[3] = GLOBALS.swinfowords[3];
		
  DINT;
  // Nur die ersten 4 Worte mit dem Firmwaredatum und Hardwarecode beschreiben

  fehler = Fapi_issueProgrammingCommand((uint32 *) 0x00082000, (void*)GLOBALS.flashbuffer, 4, 0, 0, Fapi_AutoEccGeneration);  // Programmieren
  while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}     // Warten bis Programmiervorgang abgeschlossen

  fehler += Fapi_getFsmStatus();                              // Pr�fe auf Fehler beim Programmiervorgang

  if (fehler)                                                   // Fehlermeldung versenden
  {
    Send_can(1, fehler);
    GLOBALS.flashmode = 0;
  }
  EINT;
  Send_can(2,0);													// Version der Applikation �bertragen
}

#include <LMV1_boot_definitions.h>

#pragma DATA_SECTION(flag, "global");

unsigned short int flag;

struct Globals GLOBALS;

void springe_App (void)
  {
  void (*Sprung)();

  asm(" RPT #255 || NOP");
  Sprung = (void (*)()) 0x00082004;       // An Adresse 82000 liegt Softwaredatum
  Sprung ();
  }


void main(void)
                                                                                                                                                                                                                                                                                                                                                            {
  long int temp, temp2;

  unsigned short int returncheck;

  Init_gpios();

  GpioDataRegs.GPASET.bit.GPIO13    = 1;    // Rote LED einschalten
  GpioDataRegs.GPACLEAR.bit.GPIO12  = 1;    // Gr�ne LED ausschalten

  Init_system();
  Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS, 100); // Initialize Flash API

  EALLOW;
  Flash0EccRegs.ECC_ENABLE.all = 0; // Disable ECC, ggf. sp�ter entfernen

  for (temp=0; temp<100000; temp++)
  {
    asm(" RPT #255 || NOP");
  }

  GLOBALS.antibrick = 0;


  Init_can_minimum();

  for (temp = 0; temp < 10000; temp++)                  // kurze Warteschleife mit �berpr�fung ob "Antibrick"-nachricht auf dem Bus liegt
    {
    while(HWREGH(0x0004A100U) & 0x8000) {}              // Warten bis �bertragung abgeschlossen (Busy-Bit = 0)
    HWREG_BP(0x0004A100U) = 0x003F000A;                 // lese Daten aus MB10, Arb, Control
    while(HWREGH(0x0004A100U) & 0x8000) {}              // Warten bis �bertragung abgeschlossen (Busy-Bit = 0)
    temp2 = HWREG_BP(0x0004A10CU);                      // Controlregister aus IF1 auslesen
    if (temp2 & 0x00008000)                             // Pr�fung ob neue Daten in Mbox (NewDat), wenn ja -> auswerten
      {
      temp2  =  HWREG_BP(0x0004A108U) & 0x1FFFFFFF;     // Identifier auslesen
      if (temp2 == 0x1FFFFFFA) GLOBALS.antibrick = 1;   // Antibrick-Nachricht (DLC=1)
      }
    }

  EALLOW;

  WdRegs.WDCR.all = 0x0128;                             // Watchdog, 10MHz/1024, �berlauf bei 256 -> Watchdog nach ca. 26ms

  GLOBALS.appdate = (void*) 0x00082000;                 // Erste Adresse der Applikation auslesen (Softwaredatum)

  // Wenn leer oder per Anforderung und WD-Reset aus App gekommen oder ung�ltige Applikation oder Antibrick nachricht -> in Bootloader bleiben; sonst in die App springen
  if  (!( (*GLOBALS.appdate == 0xFFFFFFFF) || (CpuSysRegs.RESC.bit.WDRSn&&(flag == 0x5A5A)) || (flag==0xF0F0) || GLOBALS.antibrick ))
  {
    IER = 0;  // Interrupts deaktivieren
    CpuTimer1Regs.TCR.bit.TSS = 1;    // Stop timer
    IFR = 0;
    flag = 0xF0F0;  // flag zur�cksetzen
    springe_App();
  }

  flag = 0;
  Init_variables();                     // Variablen vorbelegen
  Init_can();

  returncheck = Fapi_setActiveFlashBank(0);

  EINT;                                 // Globale Interrupts an

  WdRegs.WDKEY.all = 0x55;
  WdRegs.WDKEY.all = 0xAA;              // reset watchdog

  CpuTimer1Regs.TCR.bit.TSS = 0;        // Starte Timer 1

  GpioDataRegs.GPASET.bit.GPIO13    = 1;    // Rote LED einschalten
  GpioDataRegs.GPACLEAR.bit.GPIO12  = 1;    // Gr�ne LED ausschalten


  Send_can(0,0);                        // CAN-Nachrichten �bertragen
  Send_can(2,0);                        // Version der Applikation �bertragen

  while (1)                             // in ewige Schleife �bergehen
  {

  }
}


interrupt void Read_can_b_ISR(void)
{
  Read_can_b();
  CanbRegs.CAN_GLB_INT_CLR.all |= 0x0001;   // L�sche Interrupt-Flag
  PieCtrlRegs.PIEACK.all = 0x0100;          // Acknowledge PIEIER-Flag
}

interrupt void cpuTimer1ISR(void)           // Timer Interrupt alle 10ms
{
  static uint16_t timerLED = 0;
  EINT;                                     // andere Interrupts zulassen

  timerLED++;

  if (50 == timerLED)
  {
      timerLED = 0;
      // LED blinken lassen
      GpioDataRegs.GPATOGGLE.bit.GPIO12 = 1;    // Gr�ne LED abwechselnd ein- und ausschalten
      GpioDataRegs.GPATOGGLE.bit.GPIO13 = 1;    // Rote LED abwechselnd ein- und ausschalten
      Send_can(0,0);                        // CAN-Nachrichten �bertragen
      Send_can(2,0);                        // Version der Applikation �bertragen
  }

  ServiceDog();

}

//
// End of file
//

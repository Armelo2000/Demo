#ifndef __DATA_H
#define __DATA_H

#include "stm32f10x.h"

const char dataTable[] = {
	'A', 'B', 'C', 'D', 'E',
	'F', 'G', 'H', 'I', 'J',
	'K', 'L', 'M', 'N', 'O',
	'P', 'Q', 'R', 'S', 'T',
	'U', 'V', 'W', 'X', 'Y',
	'Z', '3', '0', '\r', '\n'
};

#endif

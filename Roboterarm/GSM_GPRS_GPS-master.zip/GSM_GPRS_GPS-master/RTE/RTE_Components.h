
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'STM32+GPRS' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_Drivers_USART_PL2303        /* Driver USART PL2303 */

#endif /* RTE_COMPONENTS_H */

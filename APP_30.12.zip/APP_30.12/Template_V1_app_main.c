#include "Template_V1_app_definitions.h"

#pragma CODE_SECTION(Eternal_loop, ".TI.ramfunc");

struct Cancomm CANCOMM;
struct Globals GLOBALS;


void main(void)
{
  Init_gpios();
  Init_system();
  Init_variables();                     // Variablen vorbelegen
  Init_can();
  Setup_adc();
  EALLOW;

  EINT;                                 // Globale Interrupts an
  ERTM;                                 // Debugmode Interrupt an

  CanbRegs.CAN_CTL.bit.DAR = 1;         // Disable automatic retransmission, damit sollte die Last am CAN_Controller sinken
  Eternal_loop();                       // Zur ewigen Schleife wechseln
}

void Eternal_loop(void)
{
  while (1)                                             // in ewige Schleife �bergehen
  {

    if (!CANCOMM.send_delay)                  // Zeitverz�gerte CAN-Nachricht f�r Bootloader-Identifikation
    {
      Send_boot_status();
      Send_fwdate();
      CANCOMM.send_delay = 0xFFFF;
    }
    Read_can_b();                                   // Nachrichtenauswertung
  }
}



//
// End of file
//

/* Filename: cancomm.c */

#include <LMV1_boot_definitions.h>

#pragma CODE_SECTION(Send_can, ".TI.ramfunc");
#pragma CODE_SECTION(Start_flash_action, ".TI.ramfunc");
#pragma CODE_SECTION(Receive_flashdata, ".TI.ramfunc");


void Send_can(unsigned short int mailbox, unsigned short int fehler)
{
  struct MBOX data_out;

  data_out.DATA_A.word.LOW_WORD = GLOBALS.hw_id;
  data_out.DATA_A.word.HI_WORD =  (((unsigned short int)HWCODE)<<8) + (((unsigned short int)HWCODE)>>8); // Endianess auf altes Format drehen


	if (mailbox==0)
	{
		// Ger�ter�ckmeldung
	  data_out.DATA_B.byte.BYTE4 = 0xFF;
	  data_out.DATA_B.byte.BYTE5 = SECTORS;
	  data_out.DATA_B.byte.BYTE6 = GLOBALS.flashmode;
	  data_out.DATA_B.byte.BYTE7 = GLOBALS.flashsector;
	  Send_can_b(0x1FFFFFFE, data_out.DATA_A.all, data_out.DATA_B.all, 8);
	}

	if (mailbox==1)   // Ger�ter�ckmeldung mit Fehler
	{
	  GLOBALS.fehler = 1;
	  data_out.DATA_B.byte.BYTE4 = fehler;
	  data_out.DATA_B.byte.BYTE5 = SECTORS;
	  data_out.DATA_B.byte.BYTE6 = 0xFE;
	  data_out.DATA_B.byte.BYTE7 = GLOBALS.flashsector;
    Send_can_b(0x1FFFFFFE, data_out.DATA_A.all, data_out.DATA_B.all, 8);
	}


	if (mailbox==2)   // Aktuelle Softwareversion der Applikation
	{
	  data_out.DATA_B.byte.BYTE4 = (*GLOBALS.appdate & 0x00FF0000)>>16;
	  data_out.DATA_B.byte.BYTE5 = (*GLOBALS.appdate & 0xFF000000)>>24;
	  data_out.DATA_B.byte.BYTE6 = (*GLOBALS.appdate & 0x0000FF00)>>8;
	  data_out.DATA_B.byte.BYTE7 = (*GLOBALS.appdate & 0x000000FF);
    Send_can_b(0x1FFFFFFB, data_out.DATA_A.all, data_out.DATA_B.all, 8);
	}
}



void Start_flash_action(unsigned long int data_a, unsigned long int data_b) // Vorgang ausl�sen
{
  struct MBOX data_in;

  data_in.DATA_A.all = data_a;
  data_in.DATA_B.all = data_b;

  if ( (data_in.DATA_A.word.LOW_WORD == GLOBALS.hw_id) && (data_in.DATA_A.word.HI_WORD == (((unsigned short int)HWCODE)<<8) + (((unsigned short int)HWCODE)>>8))) // nur bei passendem HW-Code und bei passender Adresse
  {
    if (!data_in.DATA_B.byte.BYTE6)
    {
      if (GLOBALS.flashmode == 2)	GLOBALS.can_counter_flash = GLOBALS.can_counter; // wenn Beenden der Flashroutine, Z�hlerstand des CAN-Counters merken
      if (GLOBALS.flashmode == 3)	// wenn Beenden der Verifyroutine
      {
        if ( (GLOBALS.can_counter_flash == GLOBALS.can_counter)&&(!GLOBALS.fehler) ) // Wenn keine Fehler und Z�hlerst�nde gleich
        {
          if (!GLOBALS.just_verify) flash_confirm(); // Wenn nicht nur einfaches verify -> Einsprungadresse flashen
        }
      }
      GLOBALS.flashmode = 0;
      Send_can(0,0);
    }
    if ( (data_in.DATA_B.byte.BYTE6 == 1) && (!GLOBALS.flashmode) )	 erase(); 		// und nur wenn idle
    if ( (data_in.DATA_B.byte.BYTE6 == 2) && (!GLOBALS.flashmode) )	 // flash			// und nur wenn idle
    {
      GLOBALS.can_counter = 0;	// n�chste Datennachricht mu� "0" im Z�hler haben
      GLOBALS.fehler = 0; 			// bei neuem Flashversuch Fehler l�schen
      GLOBALS.flashbuffercnt = 0;
      GLOBALS.flashadress = 0;
      GLOBALS.flashmode = 2;
      Send_can(0,0);
    }
    if ( (data_in.DATA_B.byte.BYTE6 == 3) && (!GLOBALS.flashmode) )	// verify			// und nur wenn idle
    {
      GLOBALS.can_counter = 0;	// n�chste Datennachricht mu� "0" im Z�hler haben
      GLOBALS.flashbuffercnt = 0;
      GLOBALS.flashadress = 0;
      GLOBALS.flashmode = 3;
      Send_can(0,0);
    }
    if ( (data_in.DATA_B.byte.BYTE6 == 4) && (!GLOBALS.flashmode) )
    {
      EALLOW;
      WdRegs.WDCR.all = 0;// Reset und nur wenn idle: Watchdog reset
      asm(" RPT#255||NOP");
    }
  }
}

void Receive_flashdata(unsigned long int data_a, unsigned long int data_b)	// Neue Datennachricht f�r Flashvorgang / Verify
{
  struct MBOX data_in;

  data_in.DATA_A.all = data_a;
  data_in.DATA_B.all = data_b;

  if ((data_in.DATA_B.byte.BYTE4 == GLOBALS.can_counter) && ((GLOBALS.flashmode == 2)||(GLOBALS.flashmode == 3)))	// Z�hler korrekt -> Daten flashen
  {
    GLOBALS.flashbuffer[GLOBALS.flashbuffercnt] = (((unsigned short int)data_in.DATA_A.word.LOW_WORD)<<8) + (((unsigned short int)data_in.DATA_A.word.LOW_WORD)>>8);
    GLOBALS.flashbuffercnt++;
    GLOBALS.flashbuffer[GLOBALS.flashbuffercnt] = (((unsigned short int)data_in.DATA_A.word.HI_WORD)<<8) + (((unsigned short int)data_in.DATA_A.word.HI_WORD)>>8);
    GLOBALS.flashbuffercnt++;
    // ersten vier Adresse erstmal nicht beschreiben
    if  ((!GLOBALS.flashadress) && (GLOBALS.flashbuffercnt==4))
    {
      GLOBALS.swinfowords[0] = GLOBALS.flashbuffer[0];
      GLOBALS.swinfowords[1] = GLOBALS.flashbuffer[1];
      GLOBALS.swinfowords[2] = GLOBALS.flashbuffer[2];
      GLOBALS.swinfowords[3] = GLOBALS.flashbuffer[3];
      GLOBALS.flashadress = 4;      // Flashvorgang beginnt ab Adresse 4
      GLOBALS.flashbuffercnt = 0;   // Flashbuffer zur�cksetzen -> es wird kein Schreibvorgang ausgel�st
    }
    if (GLOBALS.flashbuffercnt==4)
    {
      if (GLOBALS.flashmode == 2)	program();			// Wenn Puffer voll -> programmieren
      if (GLOBALS.flashmode == 3)	verify();				// Wenn Puffer voll -> vergleichen
      GLOBALS.flashadress+=4;                    // Flashadresse hochz�hlen
      GLOBALS.flashbuffercnt = 0;									// Z�hler zur�cksetzen
    }
    if (GLOBALS.can_counter==255) GLOBALS.can_counter = 0;
    else GLOBALS.can_counter++;														// Z�hler erh�hren f�r n�chste nachricht
  }
  else if ((data_in.DATA_B.byte.BYTE4 != GLOBALS.can_counter) && ((GLOBALS.flashmode == 2)||(GLOBALS.flashmode == 3)))// Z�hler falsch und im Flashmode -> Abbruch Vorgang
  {
    Send_can(1,0);
    GLOBALS.flashmode = 0;
  }
}



